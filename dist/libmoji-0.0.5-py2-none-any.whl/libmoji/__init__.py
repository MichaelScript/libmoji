#!/usr/bin/env python
from libmoji import *